"""Run a Pixel Company building with one project per floor, accessible over an SSH tunnel."""
import argparse
import hashlib
import hmac
import json
import secrets
import os
import re
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
from contextlib import closing, ExitStack
from contextvars import ContextVar
from zipfile import BadZipFile

runtime_root = Path(__file__).resolve().parent
install_root = Path(os.environ.get("PIXEL_INSTALL_ROOT", str(runtime_root))).resolve()
if __name__ == "__main__" and runtime_root == install_root:
    pointer = install_root / ".pixel-current"
    if pointer.is_file():
        release = pointer.read_text().strip()
        if not re.fullmatch(r"[0-9.]+-[0-9a-f]{16}", release):
            raise SystemExit("픽셀 컴퍼니 업데이트 위치가 올바르지 않습니다.")
        entrypoint = install_root / ".pixel-releases" / release / "server.py"
        os.environ["PIXEL_INSTALL_ROOT"] = str(install_root)
        os.execv(sys.executable, [sys.executable, str(entrypoint), *sys.argv[1:]])

from management import PLAN_SCHEMA, REPORT_SCHEMA, manager_response, run_claude

from updater import activate, latest, stage_release, version_tuple

os.umask(0o077)
parser = argparse.ArgumentParser()
parser.add_argument("--project", required=True, type=Path, action="append", help="Project folder. Repeat for additional floors.")
parser.add_argument("--port", default=8765, type=int)
parser.add_argument("--state", type=Path, default=Path.home() / ".pixel-company")
parser.add_argument("--update-feed", default=os.environ.get("PIXEL_UPDATE_FEED"),
                    help="Trusted HTTPS latest.json URL for app updates.")
args = parser.parse_args()
projects = [path.resolve() for path in args.project]
if any(not path.is_dir() for path in projects):
    parser.error("--project must point to an existing directory")
if len(set(projects)) != len(projects):
    parser.error("각 층에는 서로 다른 프로젝트 폴더를 지정해 주세요.")
claude = shutil.which("claude")
if not claude:
    parser.error("Claude Code CLI (claude) must be available on PATH")
args.state.mkdir(parents=True, exist_ok=True)
floor_projects = {hashlib.sha256(os.fsencode(path)).hexdigest(): path for path in projects}
first_floor = next(iter(floor_projects))
current_floor = ContextVar("current_floor", default=first_floor)
floors = [
    {"id": floor_id, "level": level, "name": path.name or str(path)}
    for level, (floor_id, path) in enumerate(floor_projects.items(), 1)
]


def project_path():
    return floor_projects[current_floor.get()]


def state_path(floor_id, suffix):
    return args.state / (floor_id + suffix)


token = os.environ.pop("PIXEL_RESTART_KEY", None) or secrets.token_urlsafe(32)
app_version = (runtime_root / "VERSION").read_text().strip()
update_lock = threading.RLock()
update_state = {"state": "idle", "message": ""}
active_workers = set()
restart_target = None
assets = Path(__file__).resolve().parent / "dist"
schema = {
    "type": "object",
    "properties": {
        "result": {"type": "string"},
        "question": {"type": "string"},
        "options": {"type": "array", "items": {"type": "string"}, "maxItems": 6}
    },
    "required": ["result", "question", "options"],
    "additionalProperties": False
}


def database():
    connection = sqlite3.connect(state_path(current_floor.get(), ".sqlite3"), isolation_level=None)
    connection.row_factory = sqlite3.Row
    return connection


def project_agents():
    agents = {}
    root = project_path() / ".claude" / "agents"
    for path in sorted(root.rglob("*.md")):
        try:
            with path.open(encoding="utf-8-sig") as source:
                if source.readline(4096).strip() != "---":
                    continue
                header = source.read(16384).splitlines()
        except (OSError, UnicodeError):
            continue
        name = None
        for line in header:
            if line.strip() == "---":
                if name:
                    agents.setdefault(name, {"id": name, "name": name})
                break
            if line.startswith("name:"):
                value = line.partition(":")[2].strip()
                match = re.fullmatch(r"""(?:"([a-zA-Z0-9][a-zA-Z0-9_-]*)"|'([a-zA-Z0-9][a-zA-Z0-9_-]*)'|([a-zA-Z0-9][a-zA-Z0-9_-]*))(?:\s+#.*)?""", value)
                if match:
                    name = next(group for group in match.groups() if group)
    return agents


def run_job(job, still_active):
    instructions = (
        "Work on the user's task in the current project. Report results in Korean. "
        "If a user decision or tool permission is required, stop and put the question "
        "in question and 2–6 actionable choices in options. Keep a progress summary "
        "in result. If finished, leave question empty and options empty."
    )
    prompt = job["prompt"]
    command = [claude, "-p", "--output-format", "stream-json", "--verbose", "--json-schema", json.dumps(schema),
               "--permission-mode", "default"]
    if job["agent"]:
        if job["agent"] not in project_agents():
            return ("failed", "프로젝트에서 담당 에이전트를 찾을 수 없습니다.", "", "[]", None)
        command += ["--agent", job["agent"]]
    if job["session"]:
        command += ["--resume", job["session"]]
        prompt = "User decision: " + job["decision"] + "\nContinue the original task."
    try:
        response = run_claude(command, instructions + "\n\n" + prompt, project_path(), still_active)
        result = response.get("structured_output")
        if not isinstance(result, dict):
            text = response.get("result", "")
            if isinstance(text, str) and text.strip():
                return ("done", text.strip(), "", "[]", response.get("session_id"))
            raise ValueError("Claude가 업무 결과를 반환하지 않았습니다.")
        question = result["question"].strip()
        options = [item.strip() for item in result["options"] if item.strip()]
        session = response.get("session_id")
        if question and (not options or not session):
            raise ValueError("Claude가 재개에 필요한 세션 또는 선택지를 반환하지 않았습니다.")
        return ("waiting" if question else "done", result["result"], question, json.dumps(options), session)
    except subprocess.TimeoutExpired:
        return ("failed", "Claude 실행이 15분 제한을 넘겼습니다.", "", "[]", None)
    except (ValueError, KeyError, TypeError, AttributeError, OSError) as error:
        return ("failed", str(error)[:2000], "", "[]", None)


def manager_turn(connection, job, still_active):
    manager = connection.execute("SELECT * FROM managers WHERE id=?", (job["manager_id"],)).fetchone()
    reports = [
        dict(row) for row in connection.execute(
            "SELECT agent,prompt,status,result FROM jobs WHERE parent_id=? ORDER BY rowid",
            (job["id"],)
        )
    ]
    context = json.dumps({"goal": job["prompt"], "revision": job["decision"], "employee_reports": reports},
                         ensure_ascii=False)
    if job["phase"] == "plan":
        agents = project_agents()
        choices = list(agents) or [""]
        prompt = (
            "Plan the work as the manager. Delegate 1 to 6 focused assignments to employees. "
            "Use only the exact agent IDs listed. Empty ID means the default Claude employee. "
            "Employees execute in order and share one project. Assign changes to the same file "
            "only when explicitly sequenced. User revision and past employee reports are context. "
            "Write tasks in Korean. Available IDs: " + json.dumps(choices) + "\n" + context
        )
        output, session = manager_response(manager, prompt, PLAN_SCHEMA, claude, project_path(), still_active)
        assignments = output["assignments"]
        if not 1 <= len(assignments) <= 6 or any(
            item["agent"] not in choices or not 1 <= len(item["task"].strip()) <= 6000
            for item in assignments
        ):
            raise ValueError("관리자가 유효한 직원 배정을 반환하지 않았습니다.")
        return session, assignments
    output, session = manager_response(
        manager, "Write a concise CEO report in Korean based on the actual employee results. "
        "Name unfinished work and failures. Do not claim unsupported success.\n" + context,
        REPORT_SCHEMA, claude, project_path(), still_active,
    )
    report = output["report"].strip()
    if not report:
        raise ValueError("관리자가 보고서를 반환하지 않았습니다.")
    return session, report


def worker(floor_id):
    current_floor.set(floor_id)
    with closing(database()) as connection:
        while True:
            with update_lock:
                job = None
                if update_state["state"] not in {"waiting", "restarting"}:
                    connection.execute("""
                        UPDATE jobs SET status='queued',phase='report'
                        WHERE status='delegated' AND NOT EXISTS (
                            SELECT 1 FROM jobs AS child WHERE child.parent_id=jobs.id
                            AND child.status IN ('queued','working','waiting')
                        )
                    """)
                    job = connection.execute(
                        "UPDATE jobs SET status='working' WHERE id=(SELECT id FROM jobs WHERE status='queued' ORDER BY rowid LIMIT 1) RETURNING *"
                    ).fetchone()
                    if job is not None:
                        active_workers.add(floor_id)
            if job is None:
                time.sleep(0.4)
                continue

            try:
                def still_active():
                    row = connection.execute("SELECT status,manager_id FROM jobs WHERE id=?", (job["id"],)).fetchone()
                    return row["status"] == "working" and row["manager_id"] == job["manager_id"]

                if not job["phase"]:
                    result = run_job(job, still_active)
                    connection.execute(
                        "UPDATE jobs SET status=?,result=?,question=?,options=?,session=?,event=event+1 WHERE id=? AND status='working'",
                        (*result, job["id"])
                    )
                    continue

                try:
                    session, output = manager_turn(connection, job, still_active)
                except (ValueError, KeyError, TypeError, AttributeError, OSError, subprocess.TimeoutExpired) as error:
                    connection.execute(
                        "UPDATE jobs SET status='failed',result=?,event=event+1 WHERE id=? AND status='working' AND manager_id=?",
                        (str(error)[:2000], job["id"], job["manager_id"]),
                    )
                    continue
                connection.execute("BEGIN IMMEDIATE")
                with connection:
                    if not still_active():
                        continue
                    connection.execute("UPDATE managers SET session=? WHERE id=?", (session, job["manager_id"]))
                    if job["phase"] == "plan":
                        for item in output:
                            task = item["task"].strip()
                            connection.execute(
                                "INSERT INTO jobs(id,title,prompt,status,agent,parent_id) VALUES(?,?,?,'queued',?,?)",
                                (str(uuid.uuid4()), task[:49], task, item["agent"], job["id"])
                            )
                        connection.execute("UPDATE jobs SET status='delegated' WHERE id=?", (job["id"],))
                    else:
                        connection.execute(
                            "UPDATE jobs SET status='review',result=?,event=event+1 WHERE id=?", (output, job["id"])
                        )
            finally:
                with update_lock:
                    active_workers.discard(floor_id)


def install_update(server, release):
    global restart_target
    try:
        target = stage_release(install_root, *release)
        with update_lock:
            update_state.update(state="waiting", message="진행 중인 작업이 끝나면 재시작합니다.")
        while True:
            with update_lock:
                if not active_workers:
                    activate(install_root, target)
                    restart_target = target
                    update_state.update(state="restarting", message="업데이트를 적용하고 있습니다.")
                    break
            time.sleep(0.3)
        server.shutdown()
    except (OSError, ValueError, BadZipFile, RuntimeError) as error:
        with update_lock:
            update_state.update(state="error", message=str(error)[:300])


class Handler(BaseHTTPRequestHandler):
    def send_body(self, status, body, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        self.wfile.write(body)

    def reply(self, status, data):
        self.send_body(status, json.dumps(data).encode(), "application/json")

    def local_host(self):
        host = self.headers.get("Host", "")
        return host.partition(":")[0] in {"localhost", "127.0.0.1"} and (
            ":" not in host or host.partition(":")[2].isdigit()
        )

    def authorized(self):
        supplied = self.headers.get("X-Pixel-Key", "")
        return hmac.compare_digest(supplied.encode(), token.encode())

    def select_floor(self):
        floor_id = self.headers.get("X-Pixel-Floor", "") or first_floor
        if floor_id not in floor_projects:
            self.reply(404, {"error": "프로젝트 층을 찾을 수 없습니다.", "code": "unknown_floor"})
            return False
        current_floor.set(floor_id)
        return True

    def do_GET(self):
        if not self.local_host():
            return self.reply(403, {"error": "로컬 주소에서 열어 주세요."})
        path = urlsplit(self.path).path
        if path == "/api/update":
            if not self.authorized():
                return self.reply(401, {"error": "서버 접속 키를 확인해 주세요."})
            info = {"current": app_version, "enabled": bool(args.update_feed), **update_state}
            if args.update_feed and urlsplit(self.path).query == "check=1":
                try:
                    info["latest"] = latest(args.update_feed)[0]
                    info["available"] = version_tuple(info["latest"]) > version_tuple(app_version)
                except (OSError, ValueError, RuntimeError) as error:
                    return self.reply(502, {"error": str(error)[:300]})
            return self.reply(200, info)
        if path == "/api/jobs":
            if not self.authorized():
                return self.reply(401, {"error": "서버 터미널에 표시된 전체 접속 주소로 열어 주세요."})
            if not self.select_floor():
                return
            with closing(database()) as connection:
                rows = connection.execute("SELECT id,title,prompt,status,result,question,options,decision,event,agent,manager_id,parent_id,phase FROM jobs ORDER BY rowid DESC").fetchall()
                managers = [dict(row) for row in connection.execute(
                    "SELECT id,name,provider,deleted FROM managers ORDER BY rowid"
                )]
            return self.reply(200, {"floor": current_floor.get(), "floors": floors, "managers": managers, "gpt": bool(os.environ.get("OPENAI_API_KEY")), "agents": list(project_agents().values()), "jobs": [{**dict(row), "options": json.loads(row["options"] or "[]")} for row in rows]})
        files = {"/": ("index.html", "text/html; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                 "/style.css": ("style.css", "text/css; charset=utf-8"), "/office.webp": ("office.webp", "image/webp")}
        if path not in files:
            return self.reply(404, {"error": "찾을 수 없습니다."})
        filename, content_type = files[path]
        self.send_body(200, (assets / filename).read_bytes(), content_type)

    def do_POST(self):
        origin = self.headers.get("Origin")
        if not self.local_host() or origin != "http://" + self.headers.get("Host", ""):
            return self.reply(403, {"error": "픽셀 컴퍼니 화면에서 요청해 주세요."})
        if not self.authorized():
            return self.reply(401, {"error": "서버 터미널에 표시된 전체 접속 주소로 열어 주세요."})
        if not self.select_floor():
            return
        if self.headers.get_content_type() != "application/json":
            return self.reply(415, {"error": "JSON 요청이 필요합니다."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 16384:
                raise ValueError()
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError()
        except (ValueError, UnicodeError):
            return self.reply(400, {"error": "요청 형식이 올바르지 않습니다."})
        if self.path == "/api/update":
            if not args.update_feed:
                return self.reply(409, {"error": "서버에 업데이트 배포 주소를 설정해 주세요."})
            with update_lock:
                if update_state["state"] not in {"idle", "error"}:
                    return self.reply(409, {"error": "이미 업데이트 중입니다."})
                try:
                    release = latest(args.update_feed)
                    if version_tuple(release[0]) <= version_tuple(app_version):
                        return self.reply(409, {"error": "현재 버전이 최신입니다."})
                except (OSError, ValueError, RuntimeError) as error:
                    return self.reply(502, {"error": str(error)[:300]})
                update_state.update(state="downloading", message="업데이트를 내려받고 있습니다.")
                threading.Thread(target=install_update, args=(self.server, release), daemon=True).start()
            return self.reply(202, {"version": release[0]})
        with update_lock:
            if update_state["state"] in {"waiting", "restarting"}:
                return self.reply(503, {"error": "업데이트 후 다시 시도해 주세요."})
            with closing(database()) as connection:
                if self.path.startswith("/api/manager"):
                    connection.execute("BEGIN IMMEDIATE")
                    with connection:
                        status, response = manager_action(connection, self.path, data)
                    return self.reply(status, response)
                if self.path == "/api/jobs":
                    agent = data.get("agent", "")
                    if not isinstance(agent, str) or (agent and agent not in project_agents()):
                        return self.reply(409, {"error": "프로젝트에서 이 에이전트를 찾을 수 없습니다."})
                    prompt = data.get("prompt")
                    if not isinstance(prompt, str) or not 1 <= len(prompt.strip()) <= 2000:
                        return self.reply(400, {"error": "업무 내용은 1~2000자로 입력해 주세요."})
                    prompt = prompt.strip()
                    job_id = str(uuid.uuid4())
                    connection.execute("INSERT INTO jobs(id,title,prompt,status,agent) VALUES(?,?,?,'queued',?)",
                                       (job_id, prompt[:49] + ("…" if len(prompt) > 49 else ""), prompt, agent))
                    return self.reply(201, {"id": job_id})
                if self.path == "/api/decision":
                    job_id, choice = data.get("id"), data.get("choice")
                    if not isinstance(job_id, str) or not isinstance(choice, str):
                        return self.reply(400, {"error": "선택지를 확인해 주세요."})
                    job = connection.execute("SELECT options FROM jobs WHERE id=? AND status='waiting'", (job_id,)).fetchone()
                    if job is None or choice not in json.loads(job["options"]):
                        return self.reply(409, {"error": "이미 처리됐거나 선택지가 바뀌었습니다."})
                    cursor = connection.execute("UPDATE jobs SET decision=?,status='queued' WHERE id=? AND status='waiting'", (choice, job_id))
                    return self.reply(200, {}) if cursor.rowcount else self.reply(409, {"error": "이미 처리됐습니다."})
            self.reply(404, {"error": "찾을 수 없습니다."})


def manager_action(connection, path, data):
    def error(message):
        return 409, {"error": message}

    if path == "/api/managers":
        name, provider = data.get("name"), data.get("provider")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 40 or provider not in ("claude", "gpt"):
            return error("관리자 이름과 모델을 확인해 주세요.")
        if provider == "gpt" and not os.environ.get("OPENAI_API_KEY"):
            return error("서버에 OPENAI_API_KEY를 설정한 뒤 다시 실행해 주세요.")
        manager_id = str(uuid.uuid4())
        connection.execute("INSERT INTO managers(id,name,provider) VALUES(?,?,?)", (manager_id, name.strip(), provider))
        return 201, {"id": manager_id}

    item_id = data.get("id")
    if not isinstance(item_id, str):
        return error("대상을 선택해 주세요.")
    if path == "/api/manager-goal":
        manager = connection.execute("SELECT id FROM managers WHERE id=? AND deleted=0", (item_id,)).fetchone()
        prompt = data.get("prompt")
        if not manager or not isinstance(prompt, str) or not 1 <= len(prompt.strip()) <= 2000:
            return error("관리자와 업무 내용(1~2000자)을 확인해 주세요.")
        goal_id = str(uuid.uuid4())
        connection.execute(
            "INSERT INTO jobs(id,title,prompt,status,manager_id,phase) VALUES(?,?,?,'queued',?,'plan')",
            (goal_id, prompt.strip()[:49], prompt.strip(), item_id),
        )
        return 201, {"id": goal_id}

    if path == "/api/manager-review":
        job = connection.execute(
            "SELECT jobs.*,managers.deleted FROM jobs JOIN managers ON managers.id=jobs.manager_id WHERE jobs.id=? AND jobs.status='review'",
            (item_id,),
        ).fetchone()
        if not job:
            return error("이미 처리됐거나 아직 보고서가 도착하지 않았습니다.")
        if data.get("action") == "approve":
            connection.execute("UPDATE jobs SET status='approved',event=event+1 WHERE id=?", (item_id,))
            return 200, {}
        revision = data.get("revision")
        if data.get("action") != "revise" or not isinstance(revision, str) or not 1 <= len(revision.strip()) <= 2000:
            return error("수정 지시를 입력해 주세요.")
        if job["deleted"]:
            return error("삭제된 관리자의 보고서는 승인할 수 있습니다.")
        connection.execute(
            "UPDATE jobs SET status='queued',phase='plan',decision=? WHERE id=?",
            (revision.strip(), item_id),
        )
        return 200, {}

    if path == "/api/manager-delete":
        manager = connection.execute("SELECT id FROM managers WHERE id=? AND deleted=0", (item_id,)).fetchone()
        if not manager:
            return error("이미 삭제된 관리자입니다.")
        active = ("queued", "working", "delegated")
        ids = [
            row["id"] for row in connection.execute(
                "SELECT id FROM jobs WHERE manager_id=? AND status IN (?,?,?)", (item_id, *active)
            )
        ]
        action, target = data.get("action"), data.get("target")
        if ids and action == "transfer":
            if not isinstance(target, str) or target == item_id or not connection.execute(
                "SELECT id FROM managers WHERE id=? AND deleted=0", (target,)
            ).fetchone():
                return error("업무를 받을 관리자를 선택해 주세요.")
            connection.executemany(
                "UPDATE jobs SET manager_id=?,status=CASE WHEN status='working' THEN 'queued' ELSE status END WHERE id=?",
                [(target, goal_id) for goal_id in ids],
            )
        elif ids and action == "cancel":
            for goal_id in ids:
                connection.execute("UPDATE jobs SET status='canceled',event=event+1 WHERE id=?", (goal_id,))
                connection.execute(
                    "UPDATE jobs SET status='canceled',event=event+1 WHERE parent_id=? AND status IN ('queued','working','waiting')",
                    (goal_id,),
                )
        elif ids:
            return error("진행 중인 업무를 넘길지 취소할지 선택해 주세요.")
        connection.execute("UPDATE managers SET deleted=1,session=NULL WHERE id=?", (item_id,))
        return 200, {}

    return 404, {"error": "찾을 수 없습니다."}


def initialize_database(floor_id):
    current_floor.set(floor_id)
    with closing(database()) as connection:
        connection.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, prompt TEXT NOT NULL,
            status TEXT NOT NULL, result TEXT, question TEXT, options TEXT,
            decision TEXT, session TEXT, event INTEGER NOT NULL DEFAULT 0
        )""")
        columns = {column["name"] for column in connection.execute("PRAGMA table_info(jobs)")}
        for name, definition in (
            ("agent", "TEXT NOT NULL DEFAULT ''"), ("manager_id", "TEXT"),
            ("parent_id", "TEXT"), ("phase", "TEXT"),
        ):
            if name not in columns:
                connection.execute(f"ALTER TABLE jobs ADD COLUMN {name} {definition}")
        connection.execute("""CREATE TABLE IF NOT EXISTS managers (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, provider TEXT NOT NULL,
            session TEXT, deleted INTEGER NOT NULL DEFAULT 0
        )""")
        connection.execute("UPDATE jobs SET status='failed',result='서버가 실행 도중 종료되었습니다.' WHERE status='working'")


if __name__ == "__main__":
    import fcntl
    with ExitStack() as resources:
        for floor_id, path in floor_projects.items():
            lock = resources.enter_context(state_path(floor_id, ".lock").open("a"))
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                parser.error(f"이 프로젝트의 픽셀 컴퍼니가 이미 실행 중입니다: {path}")
        server = resources.enter_context(ThreadingHTTPServer(("127.0.0.1", args.port), Handler))
        for floor_id in floor_projects:
            initialize_database(floor_id)
        for floor_id in floor_projects:
            threading.Thread(target=worker, args=(floor_id,), daemon=True).start()
        for floor in floors:
            print(f"{floor['level']}층 · {floor_projects[floor['id']]}", flush=True)
        print(f"픽셀 컴퍼니 · http://127.0.0.1:{server.server_port}/#{token}", flush=True)
        server.serve_forever()

    if restart_target is not None:
        os.environ["PIXEL_INSTALL_ROOT"] = str(install_root)
        os.environ["PIXEL_RESTART_KEY"] = token
        os.execv(sys.executable, [sys.executable, str(restart_target / "server.py"), *sys.argv[1:]])
