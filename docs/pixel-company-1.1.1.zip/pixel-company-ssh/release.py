"""Build an update feed and its ZIP into a publisher-owned directory."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from updater import RELEASE_FILES, version_tuple

parser = argparse.ArgumentParser()
parser.add_argument("output", type=Path)
args = parser.parse_args()
source = Path(__file__).resolve().parent
version = (source / "VERSION").read_text().strip()
version_tuple(version)
args.output.mkdir(parents=True, exist_ok=True)
archive = args.output / f"pixel-company-{version}.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as package:
    for name in sorted(RELEASE_FILES):
        package.write(source / name, "pixel-company-ssh/" + name)
manifest = {"version": version, "archive": archive.name,
            "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
(args.output / "latest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"Upload {archive.name}, then latest.json.")
