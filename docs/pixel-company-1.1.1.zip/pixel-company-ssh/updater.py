"""Release download and staging for per-user Pixel Company installs."""
import hashlib
import io
import json
import os
from pathlib import PurePosixPath
import re
import tempfile
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, build_opener
from zipfile import ZipFile

RELEASE_FILES = {
    "VERSION", "README.md", "server.py", "management.py", "updater.py", "release.py",
    "dist/index.html", "dist/style.css", "dist/app.js", "dist/office.webp",
}
MAX_ARCHIVE = 32 * 1024 * 1024
VERSION_RE = re.compile(r"(?:0|[1-9][0-9]{0,5})(?:\.(?:0|[1-9][0-9]{0,5})){2}")


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def version_tuple(value):
    if not isinstance(value, str) or not VERSION_RE.fullmatch(value):
        raise ValueError("배포 버전 형식을 확인해 주세요.")
    return tuple(map(int, value.split(".")))


def origin(url):
    parts = urlsplit(url)
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
        raise ValueError("업데이트 주소는 HTTPS 주소여야 합니다.")
    return parts.hostname, parts.port or 443


def download(url, limit):
    origin(url)
    with build_opener(NoRedirect()).open(url, timeout=15) as response:
        content = response.read(limit + 1)
    if len(content) > limit:
        raise ValueError("업데이트 파일 크기 제한을 초과했습니다.")
    return content


def latest(feed):
    release = json.loads(download(feed, 16_384))
    if not isinstance(release, dict):
        raise ValueError("배포 목록 형식을 확인해 주세요.")
    version_tuple(release.get("version"))
    digest = release.get("sha256")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("업데이트 체크섬 형식을 확인해 주세요.")
    archive = release.get("archive")
    if not isinstance(archive, str) or not archive:
        raise ValueError("업데이트 파일 주소가 없습니다.")
    archive_url = urljoin(feed, archive)
    if origin(archive_url) != origin(feed):
        raise ValueError("업데이트 파일은 배포 목록과 같은 서버에 있어야 합니다.")
    return release["version"], archive_url, digest


def stage_release(root, version, archive_url, digest):
    archive = download(archive_url, MAX_ARCHIVE)
    if hashlib.sha256(archive).hexdigest() != digest:
        raise ValueError("다운로드한 파일의 체크섬이 일치하지 않습니다.")
    versions = root / ".pixel-releases"
    versions.mkdir(mode=0o700, exist_ok=True)
    with ZipFile(io.BytesIO(archive)) as package, tempfile.TemporaryDirectory(dir=versions) as temp:
        from pathlib import Path

        staged = Path(temp) / "release"
        staged.mkdir()
        files = {}
        total = 0
        for entry in package.infolist():
            if entry.is_dir():
                continue
            path = PurePosixPath(entry.filename)
            name = str(path.relative_to("pixel-company-ssh"))
            if name not in RELEASE_FILES or name in files:
                raise ValueError("업데이트 압축 파일 구성이 올바르지 않습니다.")
            files[name] = entry
            total += entry.file_size
        if files.keys() != RELEASE_FILES or total > MAX_ARCHIVE:
            raise ValueError("업데이트 구성이나 압축 해제 크기가 올바르지 않습니다.")
        for name, entry in files.items():
            dest = staged / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(package.read(entry))
        if (staged / "VERSION").read_text().strip() != version:
            raise ValueError("배포 목록과 설치 파일의 버전이 다릅니다.")
        for name in ("server.py", "management.py", "updater.py", "release.py"):
            compile((staged / name).read_bytes(), name, "exec")
        target = versions / f"{version}-{digest[:16]}"
        if not target.exists():
            os.replace(staged, target)
    return target


def activate(root, target):
    with tempfile.NamedTemporaryFile(mode="w", dir=root, delete=False) as pointer:
        pointer.write(target.name + "\n")
        pointer.flush()
        os.fsync(pointer.fileno())
    os.replace(pointer.name, root / ".pixel-current")
